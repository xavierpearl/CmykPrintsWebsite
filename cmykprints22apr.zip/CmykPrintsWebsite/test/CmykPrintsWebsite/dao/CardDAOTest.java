package CmykPrintsWebsite.dao;

import static org.junit.Assert.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityNotFoundException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import CmykPrintsWebsite.entity.Card;
import CmykPrintsWebsite.entity.Category;

public class CardDAOTest extends BaseDAOTest{
	
	private static CardDAO cardDAO;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		BaseDAOTest.setUpBeforeClass();
		 cardDAO = new CardDAO(entityManager);
	}

	@Test
	public void testCreateCard() throws ParseException, IOException {
		Card  newCard = new Card();

		Category category = new Category("Pamlet");
		category.setCategoryId(10);
		newCard.setCategory(category);

		newCard.setTitle("category dc");
		newCard.setDescription(" ddddddddddddddddddddddddddddddddddddddd         category");
		newCard.setPrice(250);
		newCard.setIsbn("2323");


		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date publishDate = dateFormat.parse("02/02/1999");
		newCard.setPublishDate(publishDate);

		String imagePath ="C:\\Users\\xavier capistrano\\Desktop\\New folder\\printing-vector-11.png" ;
		
		byte[] imageBytes= Files.readAllBytes(Paths.get(imagePath));
		newCard.setImage(imageBytes);
		
		Card createdCard =cardDAO.create(newCard);
		assertTrue(createdCard.getCardId() > 0);
		
		
	}
	
	@Test
	public void testUpdateCard() throws ParseException, IOException {
		Card  existCard = new Card();
		existCard.setCardId(1);

		Category category = new Category("Wedding Card");
		category.setCategoryId(1);
		existCard.setCategory(category);

		existCard.setTitle("cabkhb");
		existCard.setDescription(" category");
		existCard.setPrice(25);
		existCard.setIsbn("233");


		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date publishDate = dateFormat.parse("02/07/1999");
		existCard.setPublishDate(publishDate);

		String imagePath ="C:\\Users\\xavier capistrano\\Desktop\\New folder\\printing-vector-11.png" ;
		
		byte[] imageBytes= Files.readAllBytes(Paths.get(imagePath));
		existCard.setImage(imageBytes);
		
		Card updateCard =cardDAO.update(existCard);
		
		assertEquals(existCard.getCategory().getCategoryId(),updateCard.getCategory().getCategoryId());

		
		
	}
	@Test 
	public void testDeleteCardSuccess(){
		Integer cardId =1;
		cardDAO.delete(cardId);
			assertTrue(true);		
		
	}

	@Test(expected = EntityNotFoundException.class)
	public void testDeleteCardFail(){
		Integer cardId=100;
		cardDAO.delete(cardId);
		
		
	}
	
	@Test 
	public void testGetCardFound(){
		Integer cardId =2;
		Card card = cardDAO.get(cardId);
	if (card != null){
		System.out.println(card.getTitle());
		}
		assertNotNull(card);
	}
	
	@Test 
	public void testGetCardNotFound(){
		Integer cardId =44;
		Card card = cardDAO.get(cardId);
		if (card == null){
			System.out.println("Not Found");
			}
		assertNull(card);
	}

	@Test
	public void testListAll(){
		List<Card> listCard =cardDAO.listAll();
		for(Card card : listCard){
			System.out.println(card.getTitle());
			}
		assertTrue(listCard.size() > 0);
	}
	
	@Test		
	public void testFindByTitle(){
			String title="category dc";
			Card card = cardDAO.findByTitle(title);
			assertNotNull(card);

	}
	@Test
	public void testCount() {
		long totalCard = cardDAO.count();
		assertEquals(2,totalCard);
	}
	
	
	
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		BaseDAOTest.tearDowmClass();
	}



}

package CmykPrintsWebsite.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;

import CmykPrintsWebsite.entity.Card;

public class CardDAO extends JpaDAO<Card> implements GenericDAO<Card> {

	public CardDAO(EntityManager entityManager) {
		super(entityManager);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Card create(Card card) {
		// TODO Auto-generated method stub
		card.setLastUpdateTime(new Date());
		return super.create(card);
	}

	@Override
	public Card update(Card card) {
		// TODO Auto-generated method stub
				card.setLastUpdateTime(new Date());
				return super.update(card);
	}

	@Override
	public Card get(Object cardId) {
		// TODO Auto-generated method stub
		return super.find(Card.class,cardId);
	}

	@Override
	public void delete(Object cardId) {
		// TODO Auto-generated method stub
		super.delete(Card.class,cardId);

		
	}

	@Override
	public List<Card> listAll() {
		// TODO Auto-generated method stub
		return super.findWithNamedQuery("Card.findAll");
	}
	public Card findByTitle(String title){
		List<Card> listCard=super.findWithNamedQuery("Card.findByTitle","title",title);
		if(listCard != null && listCard.size() > 0)
		{
		return listCard.get(0);	
		}
		return null;
	}

	@Override
	public long count() {
		return super.countWithNamedQuery("Card.countAll");
	}

}

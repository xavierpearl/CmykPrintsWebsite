package CmykPrintsWebsite.service;

import java.io.IOException;
import java.util.*;

import javax.persistence.*;
import javax.persistence.EntityManagerFactory;
import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import CmykPrintsWebsite.dao.HashGenerator;
import CmykPrintsWebsite.dao.UserDAO;
import CmykPrintsWebsite.entity.Users;

public class UserServices {

	
	private static EntityManager entityManager;
	
	private HttpServletRequest request;
	private HttpServletResponse response;
	private static UserDAO userDAO;

	public UserServices(EntityManager entityManager,HttpServletRequest request, HttpServletResponse response){
		this.request=request;
		this.response=response;
		this.entityManager= entityManager;
		userDAO =new UserDAO(entityManager);

	}
	public void listUser() throws ServletException, IOException {
		listUser(null);
	}
	public void listUser(String message) throws ServletException, IOException {

		List<Users> listUsers= userDAO.listAll();
		
		request.setAttribute("listUsers",listUsers);
		if (message != null){
			request.setAttribute("message",message);
			}
		String listpage = "user_list.jsp";
		RequestDispatcher dispatcher=request.getRequestDispatcher(listpage);
		
		dispatcher.forward(request,response);

	}
	
	
	public void createUser() throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String email=request.getParameter("email");
		String fullName=request.getParameter("fullname");
		String password=request.getParameter("password");
		
		Users existUser = userDAO.findByEmail(email);
		
		if(existUser != null){
			String message = "User with the email   " + email + "  already exists..Please try another email!";
			request.setAttribute("message",message);
			RequestDispatcher dispatcher=request.getRequestDispatcher("message.jsp");
			dispatcher.forward(request,response);
			
		}
		else{
			Users newUser = new Users(email,fullName,password);
			userDAO.create(newUser);
			listUser("new User created sucessfully");
		}
		
		
	}
	public void editUser() throws ServletException, IOException {
		int userId = Integer.parseInt(request.getParameter("id"));
		Users user = userDAO.get(userId );

		String destPage = "user_form.jsp";
		
		if (user == null) {
			destPage = "message.jsp";
			String errorMessage = "Could not find user with ID " + userId;
			request.setAttribute("message", errorMessage);
		} else {
			user.setPassword(null);
			request.setAttribute("user", user);			
		}
		
		RequestDispatcher requestDispatcher = request.getRequestDispatcher(destPage);
		requestDispatcher.forward(request, response);
		
	}
	public void updateUser() throws ServletException, IOException {
		int userId=Integer.parseInt(request.getParameter("userId"));
		String email=request.getParameter("email");
		String fullName=request.getParameter("fullname");
		String password=request.getParameter("password");
		
		Users userById=userDAO.get(userId);
		Users userByEmail=userDAO.findByEmail(email);
		
		if (userByEmail != null && userByEmail.getUserId()!= userById.getUserId()){
			String message = "Update failed as email match not found ...Please try another thee original!";
			request.setAttribute("message",message);
			RequestDispatcher dispatcher=request.getRequestDispatcher("message.jsp");
			dispatcher.forward(request,response);
		}
		else
		{
		Users user=new Users(userId,email,fullName,password);
		
		userById.setEmail(email);
		userById.setFullName(fullName);
		
		if (password != null & !password.isEmpty()) {
			String encryptedPassword = HashGenerator.generateMD5(password);
			userById.setPassword(encryptedPassword);				
		}
		
		userDAO.update(user);

		String message="User Updated sucessfully";
		listUser(message);
		}
	}
	public void deleteUser() throws ServletException, IOException {
		int userId = Integer.parseInt(request.getParameter("id"));
		
		Users user = userDAO.get(userId);
		String message = "User has been deleted successfully";
		
		if (user == null) {
			message = "Could not find user with ID " + userId
					+ ", or it might have been deleted by another admin";
			
			request.setAttribute("message", message);
			request.getRequestDispatcher("message.jsp").forward(request, response);			
		} 
		else
		{
			
			if (userId == 1) {
				message = "The default admin user account cannot be deleted.";
				
				request.setAttribute("message", message);
				request.getRequestDispatcher("message.jsp").forward(request, response);
				return;
				}
			else 
				{
				userDAO.delete(userId);
					listUser(message);
				}
			}		
		}
		public void login() throws ServletException, IOException{

				String email = request.getParameter("email");
				String password=request.getParameter("password");
				
				boolean loginResult = userDAO.checkLogin(email,password);
				
				if(loginResult){
				
					request.getSession().setAttribute("useremail",email);
					RequestDispatcher dispatcher=request.getRequestDispatcher("/admin/");
							dispatcher.forward(request,response);
					}else
					{
						String message = "Login Failed";
						request.setAttribute("message",message);

						RequestDispatcher dispatcher=request.getRequestDispatcher("login.jsp");
								dispatcher.forward(request,response);
					}

		}

}

package CmykPrintsWebsite.service;

import java.io.IOException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import CmykPrintsWebsite.dao.CategoryDAO;
import CmykPrintsWebsite.dao.UserDAO;
import CmykPrintsWebsite.entity.Category;

public class CategoryServices {
	
	private static EntityManager entityManager;
	private static CategoryDAO categoryDAO;
	private HttpServletRequest request;
	private HttpServletResponse response;
	
	public CategoryServices(EntityManager entityManager,HttpServletRequest request, HttpServletResponse response) {
		super();
		this.request = request;
		this.response = response;
		this.entityManager= entityManager;
		categoryDAO =new CategoryDAO(entityManager);
	}
	
	public void listCategory() throws ServletException, IOException {
		listCategory(null);
	}
	public void listCategory(String message) throws ServletException, IOException {
	List<Category> listCategory= categoryDAO.listAll();
		
		request.setAttribute("listCategory",listCategory);
		
		if (message != null){
			request.setAttribute("message",message);
			}
		
		String listpage = "category_list.jsp";
		RequestDispatcher dispatcher=request.getRequestDispatcher(listpage);
		
		dispatcher.forward(request,response);
		}
	
	public void createCategory() throws ServletException, IOException{
		String name =request.getParameter("name");
		
		
		Category  existCategory  = categoryDAO.findByName(name);
		if(existCategory  != null){
			String message = "Category  with the name  " + name + "  already exists..Please try another name!";
			request.setAttribute("message",message);
			RequestDispatcher dispatcher=request.getRequestDispatcher("message.jsp");
			dispatcher.forward(request,response);
			
		}
		else{
			Category  newCategory  = new Category(name);
			categoryDAO.create(newCategory );
			listCategory("new User created sucessfully");
		}
		
	}

	public void editCategory() throws ServletException, IOException {

		int categoryId = Integer.parseInt(request.getParameter("id"));
		Category category = categoryDAO.get(categoryId );

		String destPage = "category_form.jsp";
		
		if (category == null) {
			destPage = "message.jsp";
			String errorMessage = "Could not find user with ID " + categoryId;
			request.setAttribute("message", errorMessage);
		} else {
			request.setAttribute("category", category);			
		}
		
		RequestDispatcher requestDispatcher = request.getRequestDispatcher(destPage);
		requestDispatcher.forward(request, response);
	}

	public void updateCategory() throws ServletException, IOException {
		
		int categoryId=Integer.parseInt(request.getParameter("categoryId"));
		String categoryName=request.getParameter("name");
		
		
		Category categoryById=categoryDAO.get(categoryId);
		Category categoryByName=categoryDAO.findByName(categoryName);
		
		if (categoryByName != null && categoryById.getCategoryId()!= categoryByName.getCategoryId()){
			String message = "Update failed as Category Already exists ...Please try another thee original!";
			request.setAttribute("message",message);
			RequestDispatcher dispatcher=request.getRequestDispatcher("message.jsp");
			dispatcher.forward(request,response);
		}
		else
		{
		
			categoryById.setName(categoryName);
		categoryDAO.update(categoryById);

		String message="category Updated sucessfully";
		listCategory(message);
		}
	}

	public void deleteCategory() throws ServletException, IOException {

			int categoryId = Integer.parseInt(request.getParameter("id"));
		
			Category category=categoryDAO.get(categoryId);
		
		
		String message = "Category has been deleted successfully";
		
		if (category == null) {
			message = "Could not find category with ID " + categoryId
					+ ", or it might have been deleted by another admin";
			
			request.setAttribute("message", message);
			request.getRequestDispatcher("message.jsp").forward(request, response);			
		} 
		else
		{
			
			categoryDAO.delete(categoryId);
			listCategory(message);
		}
		}	
	
}
	


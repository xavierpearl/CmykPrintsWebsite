package CmykPrintsWebsite.service;

import javax.persistence.EntityManager;

import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.*;
import javax.persistence.EntityManagerFactory;
import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import CmykPrintsWebsite.dao.CardDAO;
import CmykPrintsWebsite.dao.CategoryDAO;
import CmykPrintsWebsite.entity.Card;
import CmykPrintsWebsite.entity.Category;

public class CardServices {

	private  EntityManager entityManager;
	private HttpServletRequest request;
	private HttpServletResponse response;
	private  CardDAO cardDAO;
	private CategoryDAO categoryDAO;
	
	public CardServices(EntityManager entityManager, HttpServletRequest request, HttpServletResponse response) {
		super();
		this.entityManager = entityManager;
		this.request = request;
		this.response = response;
		cardDAO =new CardDAO(entityManager);
		 categoryDAO = new CategoryDAO(entityManager);
	}

	public void listCard() throws ServletException, IOException {
		listCard(null);
	}
	public void listCard(String message) throws ServletException, IOException {
	List<Card> listCard= cardDAO.listAll();
		
		request.setAttribute("listCard",listCard);
		
		if (message != null){
			request.setAttribute("message",message);
			}
		
		String listpage = "card_list.jsp";
		RequestDispatcher dispatcher=request.getRequestDispatcher(listpage);
		
		dispatcher.forward(request,response);
		}

	public void showCardNewForm() throws ServletException, IOException {
		List<Category> listCategory = categoryDAO.listAll();
		request.setAttribute("listCategory",listCategory);
		
		
		String newpage = "card_form.jsp";
		RequestDispatcher dispatcher=request.getRequestDispatcher(newpage);
		
		dispatcher.forward(request,response);
		
	}

	public void createCard() throws ServletException, IOException {
		int categoryId = Integer.parseInt(request.getParameter("category"));
		Category category = categoryDAO.get(categoryId);
		String title = request.getParameter("title");
		String isbn = request.getParameter("isbn");
		String description = request.getParameter("description");
		float price = Float.parseFloat(request.getParameter("price"));


		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date publishDate= null;
		try{
			publishDate =dateFormat.parse(request.getParameter("publishDate"));
		}catch(ParseException ex){
		ex.printStackTrace();
		throw new ServletException("Error in pasrsing the publish date (format is mm/dd/yyyy)");
		}
		Card newCard= new Card();
		newCard.setTitle(title);
		newCard.setDescription(description);
		newCard.setIsbn(isbn);
		newCard.setPublishDate(publishDate);
		newCard.setPrice(price);
		
	
		newCard.setCategory(category);
		

		Part part  = request.getPart("cardImage");
		if (part != null && part.getSize() > 0){
			long size= part.getSize();
			byte[] imageBytes = new byte[(int) size];
			
			InputStream inputStream = part.getInputStream();
			inputStream.read(imageBytes);
			inputStream.close();
			
			newCard.setImage(imageBytes);
		 }
		
		
		Card createdCard = cardDAO.create(newCard);
		if(createdCard.getCardId() > 0){
		String message = "Anew book has been successfully uploaded";
		if (message != null){
			request.setAttribute("message",message);
			}
		listCard();
	}

	}	
}
